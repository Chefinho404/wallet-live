//! wallet-live: carteira de investimentos fullstack com Rust.
//!
//! Ponto de entrada: lê a configuração do `.env`, conecta no PostgreSQL,
//! aplica as migrations e sobe o servidor Axum.

mod api;
mod auth;
mod error;
mod models;
mod money;
mod pages;
mod repo;
mod state;

use std::sync::Arc;

use axum::Router;
use axum_extra::extract::cookie::Key;
use color_eyre::eyre::{WrapErr, eyre};
use jwt_simple::prelude::HS256Key;
use sqlx::postgres::PgPoolOptions;

use crate::state::AppState;

#[tokio::main]
async fn main() -> color_eyre::Result<()> {
    color_eyre::install()?;
    dotenvy::dotenv().ok();
    tracing_subscriber::fmt::init();

    let database_url =
        std::env::var("DATABASE_URL").wrap_err("defina DATABASE_URL no arquivo .env")?;
    let jwt_secret = std::env::var("JWT_SECRET").wrap_err("defina JWT_SECRET no arquivo .env")?;
    let cookie_secret =
        std::env::var("COOKIE_SECRET").wrap_err("defina COOKIE_SECRET no arquivo .env")?;
    let endereco = std::env::var("BIND_ADDR").unwrap_or_else(|_| "127.0.0.1:3000".to_string());

    if jwt_secret.len() < 32 {
        return Err(eyre!("JWT_SECRET precisa ter pelo menos 32 caracteres"));
    }
    if cookie_secret.len() < 64 {
        return Err(eyre!("COOKIE_SECRET precisa ter pelo menos 64 caracteres"));
    }

    let pool = PgPoolOptions::new()
        .max_connections(5)
        .connect(&database_url)
        .await
        .wrap_err("não foi possível conectar ao PostgreSQL (o Docker está rodando?)")?;

    sqlx::migrate!("./migrations")
        .run(&pool)
        .await
        .wrap_err("falha ao aplicar as migrations")?;

    let estado = AppState {
        pool,
        jwt_key: Arc::new(HS256Key::from_bytes(jwt_secret.as_bytes())),
        cookie_key: Key::from(cookie_secret.as_bytes()),
    };

    let app = Router::new()
        .merge(pages::router())
        .merge(api::router())
        .with_state(estado);

    let listener = tokio::net::TcpListener::bind(&endereco)
        .await
        .wrap_err_with(|| format!("não foi possível abrir o endereço {endereco}"))?;

    tracing::info!("wallet-live rodando em http://{endereco}");
    axum::serve(listener, app).await?;

    Ok(())
}
