use serde::{Deserialize, Serialize};

use crate::money::{centavos_para_campo, parse_brl};

pub const TIPOS: &[&str] = &["Ação", "FII", "ETF", "Renda fixa", "Cripto", "Outro"];

// Limites que impedem o cálculo quantidade x preço de estourar um i64.
pub const QUANTIDADE_MAXIMA: i64 = 100_000_000;
pub const PRECO_MAXIMO_CENTAVOS: i64 = 1_000_000_000;

/// Um ativo como está no banco (e como a API devolve).
#[derive(Debug, Clone, Serialize, sqlx::FromRow)]
pub struct Ativo {
    pub id: i64,
    pub ticker: String,
    pub nome: String,
    pub tipo: String,
    pub quantidade: i64,
    pub preco_medio_centavos: i64,
}

/// Um ativo que já passou pela validação e está pronto para ir ao banco.
#[derive(Debug)]
pub struct AtivoValido {
    pub ticker: String,
    pub nome: String,
    pub tipo: String,
    pub quantidade: i64,
    pub preco_medio_centavos: i64,
}

/// Campos do formulário HTML. Tudo texto: assim um "abc" digitado em
/// quantidade vira uma mensagem amigável, e não um erro do framework.
#[derive(Debug, Default, Deserialize)]
#[serde(default)]
pub struct AtivoForm {
    pub ticker: String,
    pub nome: String,
    pub tipo: String,
    pub quantidade: String,
    pub preco: String,
}

/// Corpo JSON da API (preço já em centavos).
#[derive(Debug, Deserialize)]
pub struct AtivoJson {
    pub ticker: String,
    pub nome: String,
    pub tipo: String,
    pub quantidade: i64,
    pub preco_medio_centavos: i64,
}

impl AtivoForm {
    pub fn de_ativo(ativo: &Ativo) -> Self {
        Self {
            ticker: ativo.ticker.clone(),
            nome: ativo.nome.clone(),
            tipo: ativo.tipo.clone(),
            quantidade: ativo.quantidade.to_string(),
            preco: centavos_para_campo(ativo.preco_medio_centavos),
        }
    }

    pub fn validar(&self) -> Result<AtivoValido, String> {
        let quantidade = self
            .quantidade
            .trim()
            .parse::<i64>()
            .map_err(|_| "A quantidade deve ser um número inteiro, como 10.".to_string())?;
        let preco = parse_brl(&self.preco)?;
        validar_ativo(&self.ticker, &self.nome, &self.tipo, quantidade, preco)
    }
}

impl AtivoJson {
    pub fn validar(&self) -> Result<AtivoValido, String> {
        validar_ativo(
            &self.ticker,
            &self.nome,
            &self.tipo,
            self.quantidade,
            self.preco_medio_centavos,
        )
    }
}

/// Regras de negócio de um ativo. Devolve a primeira mensagem de erro encontrada.
pub fn validar_ativo(
    ticker: &str,
    nome: &str,
    tipo: &str,
    quantidade: i64,
    preco_centavos: i64,
) -> Result<AtivoValido, String> {
    let ticker = ticker.trim().to_uppercase();
    if ticker.is_empty()
        || ticker.chars().count() > 12
        || !ticker.chars().all(|c| c.is_ascii_alphanumeric())
    {
        return Err("O código do ativo deve ter de 1 a 12 letras ou números, como PETR4.".into());
    }

    let nome = nome.trim();
    if nome.is_empty() || nome.chars().count() > 80 {
        return Err("Informe o nome do ativo, com até 80 caracteres.".into());
    }

    if !TIPOS.iter().any(|t| *t == tipo) {
        return Err("Escolha um tipo de ativo da lista.".into());
    }

    if !(1..=QUANTIDADE_MAXIMA).contains(&quantidade) {
        return Err("A quantidade deve ser um inteiro entre 1 e 100 milhões.".into());
    }

    if !(1..=PRECO_MAXIMO_CENTAVOS).contains(&preco_centavos) {
        return Err("O preço deve ser maior que zero e ir até R$ 10.000.000,00.".into());
    }

    Ok(AtivoValido {
        ticker,
        nome: nome.to_string(),
        tipo: tipo.to_string(),
        quantidade,
        preco_medio_centavos: preco_centavos,
    })
}

#[cfg(test)]
mod testes {
    use super::*;

    #[test]
    fn aceita_ativo_valido_e_normaliza_o_codigo() {
        let ativo = validar_ativo(" petr4 ", " Petrobras ", "Ação", 10, 3550).unwrap();
        assert_eq!(ativo.ticker, "PETR4");
        assert_eq!(ativo.nome, "Petrobras");
        assert_eq!(ativo.preco_medio_centavos, 3550);
    }

    #[test]
    fn rejeita_codigo_invalido() {
        assert!(validar_ativo("", "X", "Ação", 1, 100).is_err());
        assert!(validar_ativo("PE TR", "X", "Ação", 1, 100).is_err());
        assert!(validar_ativo("ABCDEFGHIJKLM", "X", "Ação", 1, 100).is_err());
    }

    #[test]
    fn rejeita_tipo_fora_da_lista() {
        assert!(validar_ativo("PETR4", "Petrobras", "Qualquer", 1, 100).is_err());
    }

    #[test]
    fn rejeita_quantidade_e_preco_fora_dos_limites() {
        assert!(validar_ativo("PETR4", "Petrobras", "Ação", 0, 100).is_err());
        assert!(validar_ativo("PETR4", "Petrobras", "Ação", QUANTIDADE_MAXIMA + 1, 100).is_err());
        assert!(validar_ativo("PETR4", "Petrobras", "Ação", 1, 0).is_err());
        assert!(validar_ativo("PETR4", "Petrobras", "Ação", 1, PRECO_MAXIMO_CENTAVOS + 1).is_err());
    }

    #[test]
    fn formulario_com_texto_no_lugar_de_numero_vira_mensagem() {
        let form = AtivoForm {
            ticker: "PETR4".into(),
            nome: "Petrobras".into(),
            tipo: "Ação".into(),
            quantidade: "dez".into(),
            preco: "35,50".into(),
        };
        assert!(form.validar().unwrap_err().contains("quantidade"));
    }

    #[test]
    fn formulario_completo_vira_ativo_valido() {
        let form = AtivoForm {
            ticker: "mxrf11".into(),
            nome: "Maxi Renda".into(),
            tipo: "FII".into(),
            quantidade: "25".into(),
            preco: "9,87".into(),
        };
        let ativo = form.validar().unwrap();
        assert_eq!(ativo.ticker, "MXRF11");
        assert_eq!(ativo.quantidade, 25);
        assert_eq!(ativo.preco_medio_centavos, 987);
    }
}
