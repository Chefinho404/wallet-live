//! Dinheiro como inteiro em centavos: formatar, ler e calcular pesos.

/// 123456 -> "R$ 1.234,56"
pub fn formatar_brl(centavos: i64) -> String {
    let sinal = if centavos < 0 { "-" } else { "" };
    let absoluto = centavos.unsigned_abs();
    let reais = (absoluto / 100).to_string();
    let resto = absoluto % 100;

    let mut agrupado = String::new();
    for (i, digito) in reais.chars().enumerate() {
        if i > 0 && (reais.len() - i) % 3 == 0 {
            agrupado.push('.');
        }
        agrupado.push(digito);
    }

    format!("{sinal}R$ {agrupado},{resto:02}")
}

/// 3550 -> "35,50" (valor para preencher o campo do formulário)
pub fn centavos_para_campo(centavos: i64) -> String {
    format!("{},{:02}", centavos / 100, centavos % 100)
}

/// "35,50", "35.5", "R$ 12" -> centavos. Não aceita separador de milhar.
pub fn parse_brl(entrada: &str) -> Result<i64, String> {
    let erro = || "Preço inválido. Use números, como 35,50.".to_string();

    let limpo = entrada
        .trim()
        .trim_start_matches("R$")
        .trim()
        .replace(',', ".");

    let (inteira, fracao) = match limpo.split_once('.') {
        Some((i, f)) => (i, f),
        None => (limpo.as_str(), ""),
    };

    if inteira.is_empty() && fracao.is_empty() {
        return Err(erro());
    }
    let so_digitos = |s: &str| s.chars().all(|c| c.is_ascii_digit());
    if !so_digitos(inteira) || !so_digitos(fracao) || fracao.len() > 2 {
        return Err(erro());
    }

    let reais: i64 = if inteira.is_empty() {
        0
    } else {
        inteira.parse().map_err(|_| erro())?
    };
    let centavos: i64 = match fracao.len() {
        0 => 0,
        1 => fracao.parse::<i64>().map_err(|_| erro())? * 10,
        _ => fracao.parse::<i64>().map_err(|_| erro())?,
    };

    reais
        .checked_mul(100)
        .and_then(|v| v.checked_add(centavos))
        .ok_or_else(erro)
}

/// Peso de uma parte no total, com uma casa decimal: (1, 3) -> "33,3%".
pub fn formatar_peso(parte: i64, total: i64) -> String {
    if total <= 0 {
        return "0,0%".to_string();
    }
    // i128 para a multiplicação nunca estourar.
    let decimos = (parte as i128 * 1000 / total as i128) as i64;
    format!("{},{}%", decimos / 10, decimos % 10)
}

#[cfg(test)]
mod testes {
    use super::*;

    #[test]
    fn formata_valores_em_reais() {
        assert_eq!(formatar_brl(0), "R$ 0,00");
        assert_eq!(formatar_brl(5), "R$ 0,05");
        assert_eq!(formatar_brl(123_456), "R$ 1.234,56");
        assert_eq!(formatar_brl(100_000_000), "R$ 1.000.000,00");
        assert_eq!(formatar_brl(-1_050), "-R$ 10,50");
    }

    #[test]
    fn le_precos_digitados() {
        assert_eq!(parse_brl("35,50"), Ok(3550));
        assert_eq!(parse_brl("35.5"), Ok(3550));
        assert_eq!(parse_brl("R$ 12"), Ok(1200));
        assert_eq!(parse_brl("0,05"), Ok(5));
        assert_eq!(parse_brl("  7  "), Ok(700));
    }

    #[test]
    fn rejeita_precos_invalidos() {
        assert!(parse_brl("").is_err());
        assert!(parse_brl("abc").is_err());
        assert!(parse_brl("-5").is_err());
        assert!(parse_brl("1,234").is_err());
        assert!(parse_brl("1.234,56").is_err());
    }

    #[test]
    fn campo_do_formulario_volta_ao_formato_digitado() {
        assert_eq!(centavos_para_campo(3550), "35,50");
        assert_eq!(centavos_para_campo(5), "0,05");
    }

    #[test]
    fn calcula_peso_na_carteira() {
        assert_eq!(formatar_peso(1, 3), "33,3%");
        assert_eq!(formatar_peso(50, 100), "50,0%");
        assert_eq!(formatar_peso(10, 0), "0,0%");
    }
}
