//! Acesso ao banco. Só SQL: nenhuma regra de negócio mora aqui.
//! Toda consulta de ativos filtra por `usuario_id`, então ninguém enxerga
//! (nem altera) a carteira de outra pessoa.

use sqlx::PgPool;

use crate::models::{Ativo, AtivoValido};

#[derive(Debug, sqlx::FromRow)]
pub struct Usuario {
    pub id: i64,
    pub senha_hash: String,
}

/// Verdadeiro quando o erro é "já existe" (violação de UNIQUE).
pub fn violacao_unica(erro: &sqlx::Error) -> bool {
    erro.as_database_error()
        .is_some_and(|e| e.is_unique_violation())
}

// ---------- usuários ----------

pub async fn criar_usuario(
    pool: &PgPool,
    email: &str,
    senha_hash: &str,
) -> Result<i64, sqlx::Error> {
    sqlx::query_scalar::<_, i64>(
        "INSERT INTO usuarios (email, senha_hash) VALUES ($1, $2) RETURNING id",
    )
    .bind(email)
    .bind(senha_hash)
    .fetch_one(pool)
    .await
}

pub async fn buscar_usuario_por_email(
    pool: &PgPool,
    email: &str,
) -> Result<Option<Usuario>, sqlx::Error> {
    sqlx::query_as::<_, Usuario>("SELECT id, senha_hash FROM usuarios WHERE email = $1")
        .bind(email)
        .fetch_optional(pool)
        .await
}

pub async fn email_do_usuario(pool: &PgPool, id: i64) -> Result<Option<String>, sqlx::Error> {
    sqlx::query_scalar::<_, String>("SELECT email FROM usuarios WHERE id = $1")
        .bind(id)
        .fetch_optional(pool)
        .await
}

// ---------- ativos ----------

pub async fn listar_ativos(pool: &PgPool, usuario_id: i64) -> Result<Vec<Ativo>, sqlx::Error> {
    sqlx::query_as::<_, Ativo>(
        "SELECT id, ticker, nome, tipo, quantidade, preco_medio_centavos
         FROM ativos
         WHERE usuario_id = $1
         ORDER BY ticker",
    )
    .bind(usuario_id)
    .fetch_all(pool)
    .await
}

pub async fn buscar_ativo(
    pool: &PgPool,
    usuario_id: i64,
    id: i64,
) -> Result<Option<Ativo>, sqlx::Error> {
    sqlx::query_as::<_, Ativo>(
        "SELECT id, ticker, nome, tipo, quantidade, preco_medio_centavos
         FROM ativos
         WHERE id = $1 AND usuario_id = $2",
    )
    .bind(id)
    .bind(usuario_id)
    .fetch_optional(pool)
    .await
}

pub async fn criar_ativo(
    pool: &PgPool,
    usuario_id: i64,
    ativo: &AtivoValido,
) -> Result<Ativo, sqlx::Error> {
    sqlx::query_as::<_, Ativo>(
        "INSERT INTO ativos (usuario_id, ticker, nome, tipo, quantidade, preco_medio_centavos)
         VALUES ($1, $2, $3, $4, $5, $6)
         RETURNING id, ticker, nome, tipo, quantidade, preco_medio_centavos",
    )
    .bind(usuario_id)
    .bind(&ativo.ticker)
    .bind(&ativo.nome)
    .bind(&ativo.tipo)
    .bind(ativo.quantidade)
    .bind(ativo.preco_medio_centavos)
    .fetch_one(pool)
    .await
}

pub async fn atualizar_ativo(
    pool: &PgPool,
    usuario_id: i64,
    id: i64,
    ativo: &AtivoValido,
) -> Result<Option<Ativo>, sqlx::Error> {
    sqlx::query_as::<_, Ativo>(
        "UPDATE ativos
         SET ticker = $1, nome = $2, tipo = $3, quantidade = $4,
             preco_medio_centavos = $5, atualizado_em = now()
         WHERE id = $6 AND usuario_id = $7
         RETURNING id, ticker, nome, tipo, quantidade, preco_medio_centavos",
    )
    .bind(&ativo.ticker)
    .bind(&ativo.nome)
    .bind(&ativo.tipo)
    .bind(ativo.quantidade)
    .bind(ativo.preco_medio_centavos)
    .bind(id)
    .bind(usuario_id)
    .fetch_optional(pool)
    .await
}

/// Devolve `true` se algum ativo foi apagado.
pub async fn excluir_ativo(pool: &PgPool, usuario_id: i64, id: i64) -> Result<bool, sqlx::Error> {
    let resultado = sqlx::query("DELETE FROM ativos WHERE id = $1 AND usuario_id = $2")
        .bind(id)
        .bind(usuario_id)
        .execute(pool)
        .await?;
    Ok(resultado.rows_affected() > 0)
}

/// Valor total da carteira em centavos: soma de quantidade x preço médio.
pub async fn total_carteira(pool: &PgPool, usuario_id: i64) -> Result<i64, sqlx::Error> {
    sqlx::query_scalar::<_, i64>(
        "SELECT COALESCE(SUM(quantidade * preco_medio_centavos), 0)::BIGINT
         FROM ativos
         WHERE usuario_id = $1",
    )
    .bind(usuario_id)
    .fetch_one(pool)
    .await
}
