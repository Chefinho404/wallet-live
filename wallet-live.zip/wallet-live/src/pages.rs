//! Páginas HTML (Askama) e formulários.

use askama::Template;
use axum::{
    Router,
    extract::{Form, Path, State},
    http::{StatusCode, header},
    response::{Html, IntoResponse, Redirect, Response},
    routing::{get, post},
};
use axum_extra::extract::cookie::SignedCookieJar;
use serde::Deserialize;

use crate::{
    auth::{self, AuthUser},
    error::AppError,
    models::{AtivoForm, TIPOS},
    money::{formatar_brl, formatar_peso},
    repo,
    state::AppState,
};

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/", get(raiz))
        .route("/style.css", get(estilo))
        .route("/registro", get(pagina_registro).post(registrar))
        .route("/login", get(pagina_login).post(fazer_login))
        .route("/logout", post(sair))
        .route("/dashboard", get(dashboard))
        .route("/ativos", post(criar_ativo))
        .route("/ativos/{id}", post(atualizar_ativo))
        .route("/ativos/{id}/editar", get(pagina_editar))
        .route("/ativos/{id}/excluir", post(excluir_ativo))
}

// ---------- templates ----------

#[derive(Template)]
#[template(path = "login.html")]
struct LoginTemplate {
    erro: Option<String>,
    email: String,
}

#[derive(Template)]
#[template(path = "registro.html")]
struct RegistroTemplate {
    erro: Option<String>,
    email: String,
}

/// Uma linha da tabela, com tudo já formatado para exibição.
struct AtivoView {
    id: i64,
    ticker: String,
    nome: String,
    tipo: String,
    quantidade: i64,
    preco: String,
    valor: String,
    peso: String,
}

struct TipoOpcao {
    nome: &'static str,
    selecionado: bool,
}

#[derive(Template)]
#[template(path = "dashboard.html")]
struct DashboardTemplate {
    email: String,
    total: String,
    quantidade: usize,
    ativos: Vec<AtivoView>,
    tipos: Vec<TipoOpcao>,
    form: AtivoForm,
    erro: Option<String>,
}

#[derive(Template)]
#[template(path = "editar.html")]
struct EditarTemplate {
    id: i64,
    tipos: Vec<TipoOpcao>,
    form: AtivoForm,
    erro: Option<String>,
}

fn opcoes_de_tipo(selecionado: &str) -> Vec<TipoOpcao> {
    TIPOS
        .iter()
        .map(|&nome| TipoOpcao {
            nome,
            selecionado: nome == selecionado,
        })
        .collect()
}

fn nao_encontrado() -> AppError {
    AppError::NaoEncontrado("Ativo não encontrado.".into())
}

// ---------- montagem das páginas ----------

async fn montar_dashboard(
    estado: &AppState,
    usuario_id: i64,
    form: AtivoForm,
    erro: Option<String>,
) -> Result<Html<String>, AppError> {
    let ativos = repo::listar_ativos(&estado.pool, usuario_id).await?;
    let total = repo::total_carteira(&estado.pool, usuario_id).await?;
    let email = repo::email_do_usuario(&estado.pool, usuario_id)
        .await?
        .unwrap_or_default();

    let linhas: Vec<AtivoView> = ativos
        .iter()
        .map(|a| {
            let valor = a.quantidade * a.preco_medio_centavos;
            AtivoView {
                id: a.id,
                ticker: a.ticker.clone(),
                nome: a.nome.clone(),
                tipo: a.tipo.clone(),
                quantidade: a.quantidade,
                preco: formatar_brl(a.preco_medio_centavos),
                valor: formatar_brl(valor),
                peso: formatar_peso(valor, total),
            }
        })
        .collect();

    let tipos = opcoes_de_tipo(&form.tipo);
    let pagina = DashboardTemplate {
        email,
        total: formatar_brl(total),
        quantidade: linhas.len(),
        ativos: linhas,
        tipos,
        form,
        erro,
    };
    Ok(Html(pagina.render()?))
}

fn montar_edicao(
    id: i64,
    form: AtivoForm,
    erro: Option<String>,
) -> Result<Html<String>, AppError> {
    let tipos = opcoes_de_tipo(&form.tipo);
    let pagina = EditarTemplate {
        id,
        tipos,
        form,
        erro,
    };
    Ok(Html(pagina.render()?))
}

// ---------- básico ----------

async fn raiz() -> Redirect {
    Redirect::to("/dashboard")
}

async fn estilo() -> impl IntoResponse {
    (
        [(header::CONTENT_TYPE, "text/css; charset=utf-8")],
        include_str!("../static/style.css"),
    )
}

// ---------- cadastro e login ----------

#[derive(Deserialize)]
struct CredenciaisForm {
    #[serde(default)]
    email: String,
    #[serde(default)]
    senha: String,
}

async fn pagina_registro() -> Result<Html<String>, AppError> {
    let pagina = RegistroTemplate {
        erro: None,
        email: String::new(),
    };
    Ok(Html(pagina.render()?))
}

fn registro_com_erro(
    status: StatusCode,
    email: String,
    erro: String,
) -> Result<Response, AppError> {
    let pagina = RegistroTemplate {
        erro: Some(erro),
        email,
    };
    Ok((status, Html(pagina.render()?)).into_response())
}

async fn registrar(
    State(estado): State<AppState>,
    jar: SignedCookieJar,
    Form(dados): Form<CredenciaisForm>,
) -> Result<Response, AppError> {
    let email = dados.email.trim().to_lowercase();

    if let Err(mensagem) = auth::validar_credenciais(&email, &dados.senha) {
        return registro_com_erro(StatusCode::UNPROCESSABLE_ENTITY, email, mensagem);
    }

    let hash = auth::gerar_hash(dados.senha).await?;
    let id = match repo::criar_usuario(&estado.pool, &email, &hash).await {
        Ok(id) => id,
        Err(e) if repo::violacao_unica(&e) => {
            return registro_com_erro(
                StatusCode::CONFLICT,
                email,
                "Este e-mail já tem cadastro. Entre na sua conta.".to_string(),
            );
        }
        Err(e) => return Err(e.into()),
    };

    let token = auth::criar_token(&estado.jwt_key, id)?;
    let jar = jar.add(auth::cookie_de_sessao(token));
    Ok((jar, Redirect::to("/dashboard")).into_response())
}

async fn pagina_login() -> Result<Html<String>, AppError> {
    let pagina = LoginTemplate {
        erro: None,
        email: String::new(),
    };
    Ok(Html(pagina.render()?))
}

async fn fazer_login(
    State(estado): State<AppState>,
    jar: SignedCookieJar,
    Form(dados): Form<CredenciaisForm>,
) -> Result<Response, AppError> {
    let email = dados.email.trim().to_lowercase();

    let mut id_autenticado = None;
    if let Some(usuario) = repo::buscar_usuario_por_email(&estado.pool, &email).await? {
        if auth::senha_confere(dados.senha, usuario.senha_hash).await? {
            id_autenticado = Some(usuario.id);
        }
    }

    let Some(id) = id_autenticado else {
        // Mesma mensagem para e-mail desconhecido e senha errada:
        // não revelamos quais e-mails têm conta.
        let pagina = LoginTemplate {
            erro: Some("E-mail ou senha incorretos.".to_string()),
            email,
        };
        return Ok((StatusCode::UNAUTHORIZED, Html(pagina.render()?)).into_response());
    };

    let token = auth::criar_token(&estado.jwt_key, id)?;
    let jar = jar.add(auth::cookie_de_sessao(token));
    Ok((jar, Redirect::to("/dashboard")).into_response())
}

async fn sair(jar: SignedCookieJar) -> (SignedCookieJar, Redirect) {
    (jar.remove(auth::cookie_vazio()), Redirect::to("/login"))
}

// ---------- carteira ----------

async fn dashboard(
    State(estado): State<AppState>,
    user: AuthUser,
) -> Result<Html<String>, AppError> {
    montar_dashboard(&estado, user.id, AtivoForm::default(), None).await
}

async fn criar_ativo(
    State(estado): State<AppState>,
    user: AuthUser,
    Form(form): Form<AtivoForm>,
) -> Result<Response, AppError> {
    let validado = match form.validar() {
        Ok(v) => v,
        Err(mensagem) => {
            let pagina = montar_dashboard(&estado, user.id, form, Some(mensagem)).await?;
            return Ok((StatusCode::UNPROCESSABLE_ENTITY, pagina).into_response());
        }
    };

    match repo::criar_ativo(&estado.pool, user.id, &validado).await {
        Ok(_) => Ok(Redirect::to("/dashboard").into_response()),
        Err(e) if repo::violacao_unica(&e) => {
            let mensagem = "Você já cadastrou um ativo com esse código. Edite o que já existe.";
            let pagina =
                montar_dashboard(&estado, user.id, form, Some(mensagem.to_string())).await?;
            Ok((StatusCode::CONFLICT, pagina).into_response())
        }
        Err(e) => Err(e.into()),
    }
}

async fn pagina_editar(
    State(estado): State<AppState>,
    user: AuthUser,
    Path(id): Path<i64>,
) -> Result<Html<String>, AppError> {
    let ativo = repo::buscar_ativo(&estado.pool, user.id, id)
        .await?
        .ok_or_else(nao_encontrado)?;
    montar_edicao(id, AtivoForm::de_ativo(&ativo), None)
}

async fn atualizar_ativo(
    State(estado): State<AppState>,
    user: AuthUser,
    Path(id): Path<i64>,
    Form(form): Form<AtivoForm>,
) -> Result<Response, AppError> {
    let validado = match form.validar() {
        Ok(v) => v,
        Err(mensagem) => {
            let pagina = montar_edicao(id, form, Some(mensagem))?;
            return Ok((StatusCode::UNPROCESSABLE_ENTITY, pagina).into_response());
        }
    };

    match repo::atualizar_ativo(&estado.pool, user.id, id, &validado).await {
        Ok(Some(_)) => Ok(Redirect::to("/dashboard").into_response()),
        Ok(None) => Err(nao_encontrado()),
        Err(e) if repo::violacao_unica(&e) => {
            let mensagem = "Já existe outro ativo seu com esse código.".to_string();
            let pagina = montar_edicao(id, form, Some(mensagem))?;
            Ok((StatusCode::CONFLICT, pagina).into_response())
        }
        Err(e) => Err(e.into()),
    }
}

async fn excluir_ativo(
    State(estado): State<AppState>,
    user: AuthUser,
    Path(id): Path<i64>,
) -> Result<Redirect, AppError> {
    if repo::excluir_ativo(&estado.pool, user.id, id).await? {
        Ok(Redirect::to("/dashboard"))
    } else {
        Err(nao_encontrado())
    }
}
