use std::sync::Arc;

use axum::extract::FromRef;
use axum_extra::extract::cookie::Key;
use jwt_simple::prelude::HS256Key;
use sqlx::PgPool;

/// Tudo que os handlers precisam compartilhar: banco e chaves de assinatura.
#[derive(Clone)]
pub struct AppState {
    pub pool: PgPool,
    /// Chave que assina e confere o JWT.
    pub jwt_key: Arc<HS256Key>,
    /// Chave que assina o cookie (o cookie carrega o JWT).
    pub cookie_key: Key,
}

// O `SignedCookieJar` do axum-extra procura a `Key` dentro do estado.
impl FromRef<AppState> for Key {
    fn from_ref(estado: &AppState) -> Self {
        estado.cookie_key.clone()
    }
}
