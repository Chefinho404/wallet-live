//! API JSON em `/api`. Usa a mesma sessão (cookie) das páginas.

use axum::{
    Json, Router,
    extract::{Path, State},
    http::StatusCode,
    routing::get,
};
use serde_json::json;

use crate::{
    auth::AuthUser,
    error::AppError,
    models::{Ativo, AtivoJson},
    money::formatar_brl,
    repo,
    state::AppState,
};

pub fn router() -> Router<AppState> {
    Router::new()
        .route("/api/ativos", get(listar).post(criar))
        .route("/api/ativos/{id}", get(buscar).put(atualizar))
        .route("/api/carteira", get(carteira))
}

fn nao_encontrado() -> AppError {
    AppError::NaoEncontrado("Ativo não encontrado.".into())
}

async fn listar(
    State(estado): State<AppState>,
    user: AuthUser,
) -> Result<Json<Vec<Ativo>>, AppError> {
    Ok(Json(repo::listar_ativos(&estado.pool, user.id).await?))
}

async fn buscar(
    State(estado): State<AppState>,
    user: AuthUser,
    Path(id): Path<i64>,
) -> Result<Json<Ativo>, AppError> {
    let ativo = repo::buscar_ativo(&estado.pool, user.id, id)
        .await?
        .ok_or_else(nao_encontrado)?;
    Ok(Json(ativo))
}

async fn criar(
    State(estado): State<AppState>,
    user: AuthUser,
    Json(corpo): Json<AtivoJson>,
) -> Result<(StatusCode, Json<Ativo>), AppError> {
    let validado = corpo.validar().map_err(AppError::Validacao)?;
    match repo::criar_ativo(&estado.pool, user.id, &validado).await {
        Ok(ativo) => Ok((StatusCode::CREATED, Json(ativo))),
        Err(e) if repo::violacao_unica(&e) => Err(AppError::Conflito(
            "Você já cadastrou um ativo com esse código.".into(),
        )),
        Err(e) => Err(e.into()),
    }
}

async fn atualizar(
    State(estado): State<AppState>,
    user: AuthUser,
    Path(id): Path<i64>,
    Json(corpo): Json<AtivoJson>,
) -> Result<Json<Ativo>, AppError> {
    let validado = corpo.validar().map_err(AppError::Validacao)?;
    match repo::atualizar_ativo(&estado.pool, user.id, id, &validado).await {
        Ok(Some(ativo)) => Ok(Json(ativo)),
        Ok(None) => Err(nao_encontrado()),
        Err(e) if repo::violacao_unica(&e) => Err(AppError::Conflito(
            "Já existe outro ativo seu com esse código.".into(),
        )),
        Err(e) => Err(e.into()),
    }
}

async fn carteira(
    State(estado): State<AppState>,
    user: AuthUser,
) -> Result<Json<serde_json::Value>, AppError> {
    let total = repo::total_carteira(&estado.pool, user.id).await?;
    let ativos = repo::listar_ativos(&estado.pool, user.id).await?;
    Ok(Json(json!({
        "total_centavos": total,
        "total_formatado": formatar_brl(total),
        "quantidade_ativos": ativos.len(),
    })))
}
