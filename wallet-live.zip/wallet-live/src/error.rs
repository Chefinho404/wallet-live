use axum::{
    Json,
    http::StatusCode,
    response::{IntoResponse, Response},
};
use serde_json::json;

/// Erros da aplicação. Os de infraestrutura viram "500" (e vão para o log);
/// os de regra de negócio viram uma mensagem clara para quem chamou.
#[derive(Debug, thiserror::Error)]
pub enum AppError {
    #[error("erro no banco de dados: {0}")]
    Banco(#[from] sqlx::Error),

    #[error("erro ao montar a página: {0}")]
    Template(#[from] askama::Error),

    #[error("erro ao gerar o token: {0}")]
    Token(String),

    #[error("tarefa interrompida: {0}")]
    Tarefa(#[from] tokio::task::JoinError),

    #[error("{0}")]
    Validacao(String),

    #[error("{0}")]
    Conflito(String),

    #[error("{0}")]
    NaoEncontrado(String),
}

impl IntoResponse for AppError {
    fn into_response(self) -> Response {
        let (status, mensagem) = match &self {
            AppError::Validacao(m) => (StatusCode::UNPROCESSABLE_ENTITY, m.clone()),
            AppError::Conflito(m) => (StatusCode::CONFLICT, m.clone()),
            AppError::NaoEncontrado(m) => (StatusCode::NOT_FOUND, m.clone()),
            outro => {
                // O detalhe técnico fica só no log, nunca na resposta.
                tracing::error!("{outro}");
                (
                    StatusCode::INTERNAL_SERVER_ERROR,
                    "Algo deu errado do nosso lado. Tente de novo em instantes.".to_string(),
                )
            }
        };
        (status, Json(json!({ "erro": mensagem }))).into_response()
    }
}
