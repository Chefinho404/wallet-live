//! Autenticação: senha (hash Argon2), JWT e cookie assinado.
//!
//! Fluxo: no login geramos um JWT com o id da pessoa e guardamos num cookie
//! assinado (HttpOnly). A cada requisição protegida, o extrator `AuthUser`
//! lê o cookie, confere a assinatura e valida o JWT.

use axum::{
    Json,
    extract::FromRequestParts,
    http::{StatusCode, request::Parts},
    response::{IntoResponse, Redirect, Response},
};
use axum_extra::extract::cookie::{Cookie, Key, SameSite, SignedCookieJar};
use jwt_simple::prelude::{Claims, Duration, HS256Key, MACLike};
use serde::{Deserialize, Serialize};
use serde_json::json;

use crate::{error::AppError, state::AppState};

pub const COOKIE_SESSAO: &str = "wallet_sessao";
const DURACAO_SESSAO_SEGUNDOS: u64 = 60 * 60 * 24;

/// O que guardamos dentro do JWT além do padrão (expiração etc.).
#[derive(Serialize, Deserialize)]
struct DadosSessao {
    usuario_id: i64,
}

// ---------- senha ----------
// Argon2 é de propósito lento e gasta CPU. `spawn_blocking` tira esse
// trabalho da thread que atende as requisições.

pub async fn gerar_hash(senha: String) -> Result<String, AppError> {
    Ok(tokio::task::spawn_blocking(move || password_auth::generate_hash(senha)).await?)
}

pub async fn senha_confere(senha: String, hash: String) -> Result<bool, AppError> {
    Ok(
        tokio::task::spawn_blocking(move || password_auth::verify_password(senha, &hash).is_ok())
            .await?,
    )
}

// ---------- JWT ----------

pub fn criar_token(chave: &HS256Key, usuario_id: i64) -> Result<String, AppError> {
    let claims = Claims::with_custom_claims(
        DadosSessao { usuario_id },
        Duration::from_secs(DURACAO_SESSAO_SEGUNDOS),
    );
    chave
        .authenticate(claims)
        .map_err(|e| AppError::Token(e.to_string()))
}

/// Devolve o id da pessoa se o token for autêntico e não tiver expirado.
pub fn ler_token(chave: &HS256Key, token: &str) -> Option<i64> {
    chave
        .verify_token::<DadosSessao>(token, None)
        .ok()
        .map(|claims| claims.custom.usuario_id)
}

// ---------- cookie ----------

pub fn cookie_de_sessao(token: String) -> Cookie<'static> {
    // Em produção (HTTPS) acrescente também `.secure(true)`.
    Cookie::build((COOKIE_SESSAO, token))
        .path("/")
        .http_only(true)
        .same_site(SameSite::Lax)
        .build()
}

pub fn cookie_vazio() -> Cookie<'static> {
    Cookie::build(COOKIE_SESSAO).path("/").build()
}

// ---------- extrator ----------

/// Basta colocar `user: AuthUser` nos parâmetros de um handler para protegê-lo.
#[derive(Debug, Clone, Copy)]
pub struct AuthUser {
    pub id: i64,
}

/// O que acontece quando não há sessão válida: páginas redirecionam para o
/// login; a API (`/api/...`) responde 401.
#[derive(Debug, Clone, Copy)]
pub struct SemSessao {
    api: bool,
}

impl IntoResponse for SemSessao {
    fn into_response(self) -> Response {
        if self.api {
            (
                StatusCode::UNAUTHORIZED,
                Json(json!({ "erro": "Faça login para acessar este recurso." })),
            )
                .into_response()
        } else {
            Redirect::to("/login").into_response()
        }
    }
}

impl FromRequestParts<AppState> for AuthUser {
    type Rejection = SemSessao;

    async fn from_request_parts(
        parts: &mut Parts,
        estado: &AppState,
    ) -> Result<Self, Self::Rejection> {
        let rejeicao = SemSessao {
            api: parts.uri.path().starts_with("/api"),
        };

        let jar = match SignedCookieJar::<Key>::from_request_parts(parts, estado).await {
            Ok(jar) => jar,
            Err(nunca) => match nunca {},
        };

        let cookie = jar.get(COOKIE_SESSAO).ok_or(rejeicao)?;
        let id = ler_token(&estado.jwt_key, cookie.value()).ok_or(rejeicao)?;
        Ok(AuthUser { id })
    }
}

// ---------- validação de cadastro ----------

pub fn email_valido(email: &str) -> bool {
    if email.len() > 254 || email.chars().any(char::is_whitespace) {
        return false;
    }
    match email.split_once('@') {
        Some((usuario, dominio)) => {
            !usuario.is_empty()
                && !dominio.contains('@')
                && dominio.contains('.')
                && !dominio.starts_with('.')
                && !dominio.ends_with('.')
        }
        None => false,
    }
}

pub fn validar_credenciais(email: &str, senha: &str) -> Result<(), String> {
    if !email_valido(email) {
        return Err("Informe um e-mail válido, como nome@exemplo.com.".into());
    }
    let tamanho = senha.chars().count();
    if !(8..=128).contains(&tamanho) {
        return Err("A senha precisa ter de 8 a 128 caracteres.".into());
    }
    Ok(())
}

#[cfg(test)]
mod testes {
    use super::*;

    #[test]
    fn token_vai_e_volta_com_a_mesma_chave() {
        let chave = HS256Key::from_bytes(b"uma-chave-de-teste-com-mais-de-32-caracteres");
        let token = criar_token(&chave, 42).unwrap();
        assert_eq!(ler_token(&chave, &token), Some(42));
    }

    #[test]
    fn token_com_outra_chave_ou_lixo_e_recusado() {
        let chave = HS256Key::from_bytes(b"uma-chave-de-teste-com-mais-de-32-caracteres");
        let outra = HS256Key::from_bytes(b"outra-chave-de-teste-totalmente-diferente!!");
        let token = criar_token(&chave, 42).unwrap();
        assert_eq!(ler_token(&outra, &token), None);
        assert_eq!(ler_token(&chave, "isto-nao-e-um-jwt"), None);
    }

    #[test]
    fn valida_emails() {
        assert!(email_valido("ana@exemplo.com"));
        assert!(!email_valido("ana"));
        assert!(!email_valido("@exemplo.com"));
        assert!(!email_valido("ana@exemplo"));
        assert!(!email_valido("a na@exemplo.com"));
    }

    #[test]
    fn valida_tamanho_da_senha() {
        assert!(validar_credenciais("ana@exemplo.com", "senha-forte-123").is_ok());
        assert!(validar_credenciais("ana@exemplo.com", "curta").is_err());
        assert!(validar_credenciais("ana", "senha-forte-123").is_err());
    }
}
